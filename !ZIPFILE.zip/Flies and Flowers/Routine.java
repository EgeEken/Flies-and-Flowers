public interface Routine 
{
    public boolean estReveille(int temps);
}