#!/bin/bash

javac Agent.java 
javac Mouche.java 
javac Plante.java 
javac PlanteQuiDort.java 
javac PlanteQuiDortPas.java 
javac CereusBloom.java 
javac Tulip.java 
javac VenusAttrapeMouches.java 
javac Nectar.java 
javac Routine.java
javac Ressource.java 
javac Terrain.java
javac Simulation.java 
javac TestSimulation.java 
